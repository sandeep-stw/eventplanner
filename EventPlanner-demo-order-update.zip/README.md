# Theme Studio - demo order update source bundle

This archive contains selected Copilot Studio source files for the demo order update:
agent instructions, the Build Plan topic, and the Save and Share topic.

It does not contain a Power Platform solution export, Dataverse data, or importable cloud-flow definitions. The connected Power Platform environment remains the runtime source of truth. See the repository README for the full inventory and scope.